const { Client } = require('pg');

exports.handler = async (event) => {
    const client = new Client({
        user: process.env.DB_USER,
        host: process.env.DB_ENDPOINT,
        database: process.env.DB_NAME,
        password: process.env.DB_PASSWORD,
        port: 5432, // Default port for PostgreSQL, change if necessary
    });

    await client.connect();

    try {
        const updateQuery = 'UPDATE Users SET Remaining = 0';
        const res = await client.query(updateQuery);
        console.log('Update query executed successfully:', res.command);
    } catch (err) {
        console.error('Error executing query:', err.stack);
    } finally {
        await client.end();
    }
};
